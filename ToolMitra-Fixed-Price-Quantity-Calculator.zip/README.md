# ToolMitra — refreshed PDF and online tools website

This is a static website bundle for the existing ToolMitra site. It keeps the original 31 tool cards and adds 9 PDF tools (40 tool cards total), an iLovePDF-inspired but original red/white layout, mobile responsiveness, search, category filters, policy pages, individual SEO landing pages for key PDF tools, `robots.txt`, and a sitemap configured for `https://toolmitra.com.co`.

## Included tools

### PDF tools
- Merge PDF
- Split PDF (extract a page range)
- Rotate PDF
- JPG/PNG to PDF
- PDF to JPG (one selected page)
- PDF to Word (selectable text extraction; layout may change)
- PDF to Excel (selectable text extraction; table cleanup may be needed)
- Extract PDF text
- PDF re-save / basic compressor (not a professional compression engine)
- Watermark PDF
- Add PDF page numbers
- Organize/reorder PDF pages
- Remove selected PDF pages
- Sign PDF visually (draw signature and place on first page; not a certificate-based digital signature)
- Repair PDF (best-effort read/rewrite only)
- PDF to PowerPoint (text-only editable slides; layout/images are not preserved)
- Word DOCX to PDF (text extraction; formatting/images/tables may be lost)
- Protect PDF and Unlock PDF information screens (these two operations are not implemented; no fake file conversion is performed)

### Existing image, calculator and utility tools retained
Image compressor, image resizer, JPG/PNG converter, image cropper, compress image to KB, photo for forms, QR generator, word counter, case converter, password generator, percentage, SEO listing helper, age, EMI, GST, SIP, discount, date difference, unit converter, WhatsApp link maker, salary-to-hourly calculator, plus the existing PDF tools. All original `data-tool` IDs are retained.

## Important technical notes
- This is a browser-based static website; no database or server is included.
- Libraries are loaded from CDNs, so an internet connection is required.
- Files handled by implemented browser tools are processed in the browser. Avoid using unknown online tools for highly sensitive documents.
- PDF-to-Word, PDF-to-Excel, PDF-to-PowerPoint and DOCX-to-PDF are basic text conversions and do not preserve professional layout.
- The PDF compressor currently re-saves a PDF; it does not guarantee a smaller file. Real compression, OCR, secure password encryption/decryption, scanned-PDF repair and high-fidelity conversions need a server-side engine or additional libraries.
- The contact page still has a sample email. Replace it with an email address you control before public launch or advertising applications.
- SEO landing pages and sitemap are configured for `https://toolmitra.com.co`. If the final domain is different, update the canonical URLs, sitemap, and robots sitemap line.
- Search ranking and AdSense approval cannot be guaranteed by a code update alone.

## Deploy on your existing Cloudflare Pages project (mobile-friendly instructions)
1. Download this ZIP and extract it.
2. If your Cloudflare Pages project is connected to GitHub, upload/replace the files in that same repository. Keep `index.html` at the repository root; do not create an extra enclosing folder.
3. If your project uses Cloudflare Direct Upload, upload the extracted website files/folder contents as a new deployment to the existing project. Do not delete the existing project or domain configuration.
4. Wait for deployment to finish, then open `https://toolmitra.com.co` in Chrome.
5. If the old page appears, open an Incognito tab or clear cached site data and reload.
6. Test tools with non-sensitive sample files on a phone and desktop. Some conversions need a stable internet connection and enough device memory.
7. In Google Search Console, verify the domain and submit `https://toolmitra.com.co/sitemap.xml` after deployment. Indexing and ranking take time and are not guaranteed.

## Files
- `index.html` — homepage and tool cards
- `app.js` — tool logic
- `styles.css` — responsive design
- `*-pdf.html`, `pdf-to-*.html` — SEO landing pages for key tools
- `about.html`, `privacy.html`, `terms.html`, `contact.html` — basic site information pages
- `sitemap.xml`, `robots.txt` — crawler files


## Recent update: Image Background Remover + search suggestions
- The home search now displays clickable matching tool suggestions while typing. Tap a suggestion to open that tool; Enter opens the first result.
- Added Image Background Remover using the browser-loaded `@imgly/background-removal` AI package. The first use needs internet and may download a large model; processing time depends on the device and image. Transparent PNG and white-background PNG output are available.
- If your host blocks the public CDN or the library changes, AI background removal may fail; this is a client-side implementation and does not include a paid API key.


## SEO update (2026-10-19)
- Added a dedicated, crawlable landing page for each of the 41 tool cards, including unique page title, meta description, canonical URL, social preview tags, and WebApplication structured data. FAQ structured data is included on newly generated tool pages.
- Added an internal directory linking to all tool landing pages, updated the XML sitemap to include all tool pages, and added homepage WebSite/Organization structured data.
- Canonical domain is set to `https://toolmitra.com.co`. If you use another final domain, update canonical/og URLs and sitemap before publishing.
- SEO does not guarantee Google ranking. Publish useful and accurate tools, verify the domain in Google Search Console, submit `/sitemap.xml`, check indexing and mobile usability, and improve content based on Search Console queries.
- Some tools are limited or informational only (including PDF protection/unlock); do not advertise these as fully working until the backend functionality is implemented.
- The site needs a real contact email, clear privacy policy, working tool testing, and useful original content. Do not add fake reviews or keyword stuffing.


## SEO update (2026-10-19)
- Added a dedicated, crawlable landing page for each of the 41 tool cards, including unique page title, meta description, canonical URL, social preview tags, and WebApplication structured data. FAQ structured data is included on newly generated tool pages.
- Added an internal directory linking to all tool landing pages, updated the XML sitemap to include all tool pages, and added homepage WebSite/Organization structured data.
- Canonical domain is set to `https://toolmitra.com.co`. If you use another final domain, update canonical/og URLs and sitemap before publishing.
- SEO does not guarantee Google ranking. Publish useful and accurate tools, verify the domain in Google Search Console, submit `/sitemap.xml`, check indexing and mobile usability, and improve content based on Search Console queries.
- Some tools are limited or informational only (including PDF protection/unlock); do not advertise these as fully working until the backend functionality is implemented.
- The site needs a real contact email, clear privacy policy, working tool testing, and useful original content. Do not add fake reviews or keyword stuffing.


## Latest additions (October 2026)
- Added a Professional Resume Maker with a generated preview and PDF / editable Word DOCX export. Profile photo is optional.
- Added a fast, lightweight person-cutout method to Background Remover using MediaPipe Selfie Segmentation, plus the slower AI object/product method. Fast mode is best for people; use AI Object mode for product photos.
- Existing tool cards and pages were retained; only the requested new resume tool and background-removal method selector were added.


## Resume Maker refinement (2026-10-20)
- Reworked the resume form and preview to follow a clean, blue-heading, A4 professional CV structure: career objective, professional experience, academic credentials in a table, key skills, projects/certifications, and optional personal details.
- Added optional profile photo, theme choices, PDF and editable Word downloads, and mobile-responsive styling.
- Added an AI Assist button that opens ChatGPT with a prepared prompt based on the user's entered career facts. This static site does not include a private AI API key or its own AI backend; AI writing happens in ChatGPT and the user pastes approved text back into the resume form. Never invent credentials or achievements.
- The provided resume PDF was used as a visual structure reference; personal details from that sample were not hard-coded into the public tool.
